
# 📚 PDF to Flashcards

✨ تحويل أي PDF إلى بطاقات تعليمية (Flashcards) بكل التفاصيل!  
مع ستايل **Pinterest + Anime aesthetic**، وألوان **Wisteria & Lemon**.

## Features
- توليد **بطاقات لكل الجمل والفقرات** في PDF، بدون تجاهل أي نص.
- تصميم **جذاب ومريح للعين** مع flip animation للبطاقات.
- Responsive: يعمل على **الكمبيوتر، التابلت، والموبايل**.
- يدعم **اللغة العربية والإنجليزية** (إذا كان النص قابل للاستخراج من PDF).

## How to Use
1. افتح الموقع على الرابط: `https://your-username.github.io/repo-name/`
2. اضغط **Upload PDF** واختر الملف من جهازك.
3. اضغط **توليد البطاقات**.
4. استمتع بالبطاقات، اضغط على أي بطاقة لتقليبها ورؤية الإجابة.

## Colors & Style
- **Primary:** Wisteria (#C9A0DC)  
- **Secondary:** Lemon (#FFF44F)  
- Grid مستوحاة من Pinterest مع لمسة Anime aesthetic ✨

## Tech Stack
- HTML / CSS / JS
- [pdf.js](https://mozilla.github.io/pdf.js/) لتحويل PDF إلى نصوص
- Responsive & modern design
