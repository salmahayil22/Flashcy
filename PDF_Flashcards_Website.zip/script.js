
const script = document.createElement('script');
script.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js";
document.head.appendChild(script);

script.onload = () => {
  pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js";

  document.getElementById('generateBtn').addEventListener('click', async () => {
    const fileInput = document.getElementById('pdfInput');
    const file = fileInput.files[0];
    if (!file) { alert('يرجى رفع ملف PDF أولاً!'); return; }

    const flashcardsContainer = document.getElementById('flashcards');
    flashcardsContainer.innerHTML = '<p>⏳ جاري استخراج النص وتوليد البطاقات...</p>';

    try {
      const pdf = await pdfjsLib.getDocument(URL.createObjectURL(file)).promise;
      let fullText = '';
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        fullText += textContent.items.map(item => item.str).join(' ') + '\n';
      }

      const lines = fullText.split('\n').filter(line => line.trim().length > 0);
      const flashcards = lines.map(line => {
        const trimmed = line.trim();
        const question = `ما هو التفصيل أو الفكرة الرئيسية في: "${trimmed.slice(0,50)}..."؟`;
        const answer = trimmed;
        return { question, answer };
      });

      flashcardsContainer.innerHTML = '';
      flashcards.forEach(card => {
        const cardElement = document.createElement('div');
        cardElement.className = 'flashcard';
        cardElement.innerHTML = `
          <div class="front">${card.question}</div>
          <div class="back">${card.answer}</div>
        `;
        cardElement.addEventListener('click', () => cardElement.classList.toggle('flipped'));
        flashcardsContainer.appendChild(cardElement);
      });

    } catch (err) {
      console.error(err);
      flashcardsContainer.innerHTML = '<p>⚠️ حدث خطأ، تأكد أن PDF يحتوي على نص قابل للاستخراج.</p>';
    }
  });
};
